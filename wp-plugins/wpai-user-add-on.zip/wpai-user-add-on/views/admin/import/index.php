<input type="hidden" name="title" value="user"/>
<input type="hidden" name="content" value="user"/>

<?php include( 'options/_main_options_template.php' ); ?>						